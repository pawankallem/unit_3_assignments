async function apiCall(url) {


    //add api call logic here


}


function appendArticles(articles, main) {

    //add append logic here

}

export { apiCall, appendArticles }